# Создателю архива с SPython:
Запустить файл collect.bat. Полученный архив SPython.zip готов к отправке.

# Пользователю SPython:
Запустить файл install.bat с указанием пути к папке с установленным PascalABC.NET
(По умолчанию путь определен как "C:\\Program Files (x86)\\PascalABC.NET\\")