﻿namespace WindowsFormsApplication1
{
    partial class MemberForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MemberForm));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tbRemarks = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tbSample = new System.Windows.Forms.TextBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tbDescription = new System.Windows.Forms.TextBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbCode = new System.Windows.Forms.ToolStripButton();
            this.toolStrip3 = new System.Windows.Forms.ToolStrip();
            this.tsbParagraph = new System.Windows.Forms.ToolStripButton();
            this.tsbTypeCRef = new System.Windows.Forms.ToolStripButton();
            this.tsbMethodCRef = new System.Windows.Forms.ToolStripButton();
            this.tsbPropertyCRef = new System.Windows.Forms.ToolStripButton();
            this.tsbEventCRef = new System.Windows.Forms.ToolStripButton();
            this.tsbFieldCRef = new System.Windows.Forms.ToolStripButton();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.toolStrip3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 111);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(534, 263);
            this.tabControl1.TabIndex = 12;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.toolStrip3);
            this.tabPage1.Controls.Add(this.tbRemarks);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(526, 237);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Заметки";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tbRemarks
            // 
            this.tbRemarks.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tbRemarks.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbRemarks.Location = new System.Drawing.Point(3, 31);
            this.tbRemarks.Multiline = true;
            this.tbRemarks.Name = "tbRemarks";
            this.tbRemarks.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbRemarks.Size = new System.Drawing.Size(520, 203);
            this.tbRemarks.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.toolStrip1);
            this.tabPage2.Controls.Add(this.tbSample);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(526, 237);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Пример кода";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tbSample
            // 
            this.tbSample.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tbSample.Location = new System.Drawing.Point(3, 31);
            this.tbSample.Multiline = true;
            this.tbSample.Name = "tbSample";
            this.tbSample.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbSample.Size = new System.Drawing.Size(520, 203);
            this.tbSample.TabIndex = 0;
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(471, 380);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 11;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnOK
            // 
            this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOK.Location = new System.Drawing.Point(380, 380);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 10;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Описание";
            // 
            // tbDescription
            // 
            this.tbDescription.Location = new System.Drawing.Point(12, 28);
            this.tbDescription.Multiline = true;
            this.tbDescription.Name = "tbDescription";
            this.tbDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbDescription.Size = new System.Drawing.Size(534, 68);
            this.tbDescription.TabIndex = 8;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbCode});
            this.toolStrip1.Location = new System.Drawing.Point(3, 3);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(520, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbCode
            // 
            this.tsbCode.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbCode.Image = ((System.Drawing.Image)(resources.GetObject("tsbCode.Image")));
            this.tsbCode.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbCode.Name = "tsbCode";
            this.tsbCode.Size = new System.Drawing.Size(33, 22);
            this.tsbCode.Text = "<c>";
            this.tsbCode.Click += new System.EventHandler(this.tsbCode_Click);
            // 
            // toolStrip3
            // 
            this.toolStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbParagraph,
            this.tsbTypeCRef,
            this.tsbMethodCRef,
            this.tsbPropertyCRef,
            this.tsbEventCRef,
            this.tsbFieldCRef});
            this.toolStrip3.Location = new System.Drawing.Point(3, 3);
            this.toolStrip3.Name = "toolStrip3";
            this.toolStrip3.Size = new System.Drawing.Size(520, 25);
            this.toolStrip3.TabIndex = 2;
            this.toolStrip3.Text = "toolStrip3";
            // 
            // tsbParagraph
            // 
            this.tsbParagraph.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbParagraph.Image = ((System.Drawing.Image)(resources.GetObject("tsbParagraph.Image")));
            this.tsbParagraph.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbParagraph.Name = "tsbParagraph";
            this.tsbParagraph.Size = new System.Drawing.Size(34, 22);
            this.tsbParagraph.Text = "<p>";
            this.tsbParagraph.Click += new System.EventHandler(this.tsbParagraph_Click);
            // 
            // tsbTypeCRef
            // 
            this.tsbTypeCRef.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbTypeCRef.Image = ((System.Drawing.Image)(resources.GetObject("tsbTypeCRef.Image")));
            this.tsbTypeCRef.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbTypeCRef.Name = "tsbTypeCRef";
            this.tsbTypeCRef.Size = new System.Drawing.Size(70, 22);
            this.tsbTypeCRef.Text = "<cref \"T:\">";
            this.tsbTypeCRef.Click += new System.EventHandler(this.tsbTypeCRef_Click);
            // 
            // tsbMethodCRef
            // 
            this.tsbMethodCRef.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbMethodCRef.Image = ((System.Drawing.Image)(resources.GetObject("tsbMethodCRef.Image")));
            this.tsbMethodCRef.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbMethodCRef.Name = "tsbMethodCRef";
            this.tsbMethodCRef.Size = new System.Drawing.Size(74, 22);
            this.tsbMethodCRef.Text = "<cref \"M:\">";
            this.tsbMethodCRef.Click += new System.EventHandler(this.tsbMethodCRef_Click);
            // 
            // tsbPropertyCRef
            // 
            this.tsbPropertyCRef.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbPropertyCRef.Image = ((System.Drawing.Image)(resources.GetObject("tsbPropertyCRef.Image")));
            this.tsbPropertyCRef.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPropertyCRef.Name = "tsbPropertyCRef";
            this.tsbPropertyCRef.Size = new System.Drawing.Size(70, 22);
            this.tsbPropertyCRef.Text = "<cref \"P:\">";
            this.tsbPropertyCRef.Click += new System.EventHandler(this.tsbPropertyCRef_Click);
            // 
            // tsbEventCRef
            // 
            this.tsbEventCRef.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbEventCRef.Image = ((System.Drawing.Image)(resources.GetObject("tsbEventCRef.Image")));
            this.tsbEventCRef.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbEventCRef.Name = "tsbEventCRef";
            this.tsbEventCRef.Size = new System.Drawing.Size(69, 22);
            this.tsbEventCRef.Text = "<cref \"E:\">";
            this.tsbEventCRef.Click += new System.EventHandler(this.tsbEventCRef_Click);
            // 
            // tsbFieldCRef
            // 
            this.tsbFieldCRef.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbFieldCRef.Image = ((System.Drawing.Image)(resources.GetObject("tsbFieldCRef.Image")));
            this.tsbFieldCRef.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbFieldCRef.Name = "tsbFieldCRef";
            this.tsbFieldCRef.Size = new System.Drawing.Size(69, 22);
            this.tsbFieldCRef.Text = "<cref \"F:\">";
            this.tsbFieldCRef.Click += new System.EventHandler(this.tsbFieldCRef_Click);
            // 
            // MemberForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(558, 412);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbDescription);
            this.Name = "MemberForm";
            this.Text = "MemberForm";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.toolStrip3.ResumeLayout(false);
            this.toolStrip3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox tbRemarks;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox tbSample;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbDescription;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbCode;
        private System.Windows.Forms.ToolStrip toolStrip3;
        private System.Windows.Forms.ToolStripButton tsbParagraph;
        private System.Windows.Forms.ToolStripButton tsbTypeCRef;
        private System.Windows.Forms.ToolStripButton tsbMethodCRef;
        private System.Windows.Forms.ToolStripButton tsbPropertyCRef;
        private System.Windows.Forms.ToolStripButton tsbEventCRef;
        private System.Windows.Forms.ToolStripButton tsbFieldCRef;
    }
}