﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Net;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;

namespace WindowsFormsApplication1
{
    public partial class TypeForm : Form
    {
        public DocCommentEditor.TypeInfo EditedType;
        public TypeForm()
        {
            InitializeComponent();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            this.tbDescription.Text = EditedType.Description;
            this.Text = EditedType.Name;
            this.tbRemarks.Text = EditedType.Remarks;
            this.tbSample.Text = EditedType.SampleCode;
            loadMembers();
        }

        private void loadMembers()
        {
            for (int i = 0; i < EditedType.Members.Count; i++)
            {
                dgvMembers.Rows.Add(EditedType.Members[i].Name, EditedType.Members[i].Description);
                Utils.highlightRow(EditedType.Members[i], dgvMembers.Rows[i]);
            }
        }

        private void btnMsdn_Click(object sender, EventArgs e)
        {
            this.tbRemarks.Text = getRemarks();
        }

        public string Remarks
        {
            get { return tbRemarks.Text; }
        }

        public string SampleCode
        {
            get { return tbSample.Text; }
        }

        const string HTML_TAG_PATTERN = "<.*?>";
        const string HTML_PSTARTTAG_PATTERN = "<p.*?>";
        const string HTML_PENDTAG_PATTERN = "</p>";

        static string StripHTML(string inputString)
        {
            //inputString = Regex.Replace(inputString, HTML_PSTARTTAG_PATTERN,"<p>");
            //inputString = Regex.Replace(inputString, HTML_PENDTAG_PATTERN, "</p>\r\n\r\n");
            inputString = inputString.Replace("<p>", "@!<p>");
            inputString = inputString.Replace("</p>","</p>!@");
            inputString = Regex.Replace(inputString, HTML_TAG_PATTERN, string.Empty);
            inputString = inputString.Replace("@!","<p>");
            inputString = inputString.Replace("!@", "</p>\r\n\r\n");
            return inputString;
        }

        private string getRemarks()
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create("http://msdn.microsoft.com/ru-ru/library/" + EditedType.Name.ToLower() + "(v=VS.90).aspx");
            //request.SendChunked = true;
            //request.TransferEncoding = "UTF-8";
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            
            // we will read data via the response stream
            Stream resStream = response.GetResponseStream();
            string tempString = null;
            int count = 0;
            StringBuilder sb = new StringBuilder();
            byte[] buf = new byte[8192];

            do
            {
                // fill the buffer with data
                count = resStream.Read(buf, 0, buf.Length);

                // make sure we read some data
                if (count != 0)
                {
                    // translate from bytes to ASCII text
                    tempString = Encoding.UTF8.GetString(buf, 0, count);

                    // continue building the string
                    sb.Append(tempString);
                }
            }
            while (count > 0); // any more data to read?

            String site = sb.ToString();
            int ind = site.IndexOf("Заметки");
            if (ind != -1)
            {
                int end_ind = site.IndexOf("LW_CollapsibleArea_Title", ind+7);
                if (end_ind != -1)
                {
                    return StripHTML(site.Substring(ind, end_ind-ind+1-7));
                }
            }
            return "";
        }

        private void dgvMembers_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            MemberForm mf = new MemberForm();
            mf.EditedMember = EditedType.Members[e.RowIndex];
            if (mf.ShowDialog() == DialogResult.OK)
            {
                mf.EditedMember.Remarks = mf.Remarks;
                mf.EditedMember.SampleCode = mf.SampleCode;
                Utils.highlightRow(mf.EditedMember, dgvMembers.Rows[e.RowIndex]);

            }
        }

        private void tbRemarks_KeyPress(object sender, KeyPressEventArgs e)
        {
           
        }

        private void tbRemarks_KeyDown(object sender, KeyEventArgs e)
        {
        }

        private void tsbTypeCRef_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(tbRemarks.SelectedText))
            {
                int sel_start = tbRemarks.SelectionStart;
                int sel_len = tbRemarks.SelectionLength;
                StringBuilder sb = new StringBuilder();
                string type_ref = "";
                int dot_ind = tbRemarks.SelectedText.IndexOf(".");
                if (dot_ind != -1)
                    type_ref = "T:" + tbRemarks.SelectedText;
                else
                {
                    if (this.EditedType.Name.Substring(this.EditedType.Name.LastIndexOf(".") + 1) != tbRemarks.SelectedText)
                    {
                        type_ref = "T:" + tbRemarks.SelectedText;
                    }
                    else
                        type_ref = "T:" + "System."+this.EditedType.Name;
                }
                sb.Append(tbRemarks.Text.Substring(0, sel_start));
                sb.Append(string.Format("<see cref=\"{0}\"/>",type_ref));
                sb.Append(tbRemarks.Text.Substring(sel_start + sel_len));
                tbRemarks.Text = sb.ToString();
                tbRemarks.SelectionStart = sel_start;
                tbRemarks.ScrollToCaret();
            }
        }

        private void tsbParagraph_Click(object sender, EventArgs e)
        {
            int sel_start = tbRemarks.SelectionStart;
            int sel_len = tbRemarks.SelectionLength;
            if (!string.IsNullOrEmpty(tbRemarks.SelectedText))
            {
                StringBuilder sb = new StringBuilder();
                sb.Append(tbRemarks.Text.Substring(0, sel_start));
                sb.Append("<p>" + tbRemarks.SelectedText + "</p>");
                sb.Append(tbRemarks.Text.Substring(sel_start + sel_len));
                tbRemarks.Text = sb.ToString();
                tbRemarks.SelectionStart = sel_start;
                tbRemarks.ScrollToCaret();
            }
            else
            {
                tbRemarks.Text = tbRemarks.Text.Replace("\r\n\r\n", "</p>\r\n\r\n<p>");
                tbRemarks.Text = "<p>" + tbRemarks.Text + "</p>";
            }
        }

        private void tsbMethodCRef_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(tbRemarks.SelectedText))
            {
                int sel_start = tbRemarks.SelectionStart;
                int sel_len = tbRemarks.SelectionLength;
                StringBuilder sb = new StringBuilder();
                string method_ref = "";
                int dot_ind = tbRemarks.SelectedText.IndexOf(".");
                if (dot_ind != -1)
                    method_ref = "M:" + tbRemarks.SelectedText;
                else
                {
                    method_ref = "M:" + "System." + this.EditedType.Name + "." + tbRemarks.SelectedText;
                }
                sb.Append(tbRemarks.Text.Substring(0, sel_start));
                sb.Append(string.Format("<see cref=\"{0}\"/>", method_ref));
                sb.Append(tbRemarks.Text.Substring(sel_start + sel_len));
                tbRemarks.Text = sb.ToString();
                tbRemarks.SelectionStart = sel_start;
                tbRemarks.ScrollToCaret();
            }
        }

        private void tsbPropertyCRef_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(tbRemarks.SelectedText))
            {
                int sel_start = tbRemarks.SelectionStart;
                int sel_len = tbRemarks.SelectionLength;
                StringBuilder sb = new StringBuilder();
                string prop_ref = "";
                int dot_ind = tbRemarks.SelectedText.IndexOf(".");
                if (dot_ind != -1)
                    prop_ref = "P:" + tbRemarks.SelectedText;
                else
                {
                    prop_ref = "P:" + "System." + this.EditedType.Name + "." + tbRemarks.SelectedText;
                }
                sb.Append(tbRemarks.Text.Substring(0, sel_start));
                sb.Append(string.Format("<see cref=\"{0}\"/>", prop_ref));
                sb.Append(tbRemarks.Text.Substring(sel_start + sel_len));
                tbRemarks.Text = sb.ToString();
                tbRemarks.SelectionStart = sel_start;
                tbRemarks.ScrollToCaret();
            }
        }

        private void tsbEventCRef_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(tbRemarks.SelectedText))
            {
                int sel_start = tbRemarks.SelectionStart;
                int sel_len = tbRemarks.SelectionLength;
                StringBuilder sb = new StringBuilder();
                string event_ref = "";
                int dot_ind = tbRemarks.SelectedText.IndexOf(".");
                if (dot_ind != -1)
                    event_ref = "E:" + tbRemarks.SelectedText;
                else
                {
                    event_ref = "E:" + "System." + this.EditedType.Name + "." + tbRemarks.SelectedText;
                }
                sb.Append(tbRemarks.Text.Substring(0, sel_start));
                sb.Append(string.Format("<see cref=\"{0}\"/>", event_ref));
                sb.Append(tbRemarks.Text.Substring(sel_start + sel_len));
                tbRemarks.Text = sb.ToString();
                tbRemarks.SelectionStart = sel_start;
                tbRemarks.ScrollToCaret();
            }
        }

        private void tsbFieldCRef_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(tbRemarks.SelectedText))
            {
                int sel_start = tbRemarks.SelectionStart;
                int sel_len = tbRemarks.SelectionLength;
                StringBuilder sb = new StringBuilder();
                string field_ref = "";
                int dot_ind = tbRemarks.SelectedText.IndexOf(".");
                if (dot_ind != -1)
                    field_ref = "F:" + tbRemarks.SelectedText;
                else
                {
                    field_ref = "F:" + "System." + this.EditedType.Name + "." + tbRemarks.SelectedText;
                }
                sb.Append(tbRemarks.Text.Substring(0, sel_start));
                sb.Append(string.Format("<see cref=\"{0}\"/>", field_ref));
                sb.Append(tbRemarks.Text.Substring(sel_start + sel_len));
                tbRemarks.Text = sb.ToString();
                tbRemarks.SelectionStart = sel_start;
                tbRemarks.ScrollToCaret();
            }
        }

        private void tsbCode_Click(object sender, EventArgs e)
        {
            tbSample.Text += "<code lang=\"pascalabcnet\" source=\"PABCExamples\\<file>.pas\"/>";
        }
    }
}
