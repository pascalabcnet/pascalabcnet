﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Xml;
using System.Windows.Forms;
using DocCommentEditor;

namespace WindowsFormsApplication1
{
    class Utils
    {
        public static void highlightRow(ObjectInfo ti, DataGridViewRow row)
        {
            if (!string.IsNullOrEmpty(ti.Remarks) && !string.IsNullOrEmpty(ti.SampleCode))
                row.DefaultCellStyle.BackColor = Color.Green;
            else if (!string.IsNullOrEmpty(ti.Remarks) || !string.IsNullOrEmpty(ti.SampleCode))
                row.DefaultCellStyle.BackColor = Color.Yellow;
        }
    }

    public static class XmlCommentManager
    {
        private static List<DocXmlEntity> xmlEntities = new List<DocXmlEntity>();
        private static List<TypeInfo> types = new List<TypeInfo>();
        private static Dictionary<string, TypeInfo> type_cache = new Dictionary<string, TypeInfo>();
        private static Dictionary<string, MemberInfo> member_cache = new Dictionary<string, MemberInfo>();

        private static string xmlFileName;
        private static string assemblyName;

        public static string XmlFileName
        {
            get
            {
                return xmlFileName;
            }
            set
            {
                xmlFileName = value;
            }
        }

        public static string AssemblyName
        {
            get
            {
                return assemblyName;
            }
        }

        public static List<DocXmlEntity> XmlEntities
        {
            get
            {
                return xmlEntities;
            }
        }

        public static List<TypeInfo> Types
        {
            get
            {
                return types;
            }
        }

        public static Dictionary<string, TypeInfo> TypeCache
        {
            get
            {
                return type_cache;
            }
        }

        public static Dictionary<string, MemberInfo> MemberCache
        {
            get
            {
                return member_cache;
            }
        }

        public static void Clear()
        {
            xmlEntities.Clear();
            types.Clear();
            type_cache.Clear();
            member_cache.Clear();
            xmlFileName = null;
            assemblyName = null;

        }

        public static void loadXml(string FileName)
        {
            Clear();
            using (XmlTextReader reader = new XmlTextReader(FileName))
            {
                while (reader.Read())
                {
                    if (reader.IsStartElement())
                    {
                        switch (reader.LocalName)
                        {
                            case "members": readMembersSection(reader); break;
                            case "doc": readMembersSection(reader); break;
                        }
                    }
                }
            }
        }

        public static void readMembersSection(XmlTextReader reader)
        {
            while (reader.Read())
            {
                switch (reader.NodeType)
                {
                    case XmlNodeType.EndElement:
                        if (reader.LocalName == "members")
                        {
                            return;
                        }
                        break;
                    case XmlNodeType.Element:
                        if (reader.LocalName == "member")
                        {
                            string memberAttr = reader.GetAttribute(0);
                            string innerXml = reader.ReadInnerXml();
                            xmlEntities.Add(new DocXmlEntity(memberAttr, innerXml));
                            if (memberAttr.StartsWith("T:"))
                            {
                                TypeInfo ti = new TypeInfo(memberAttr.Substring(2), innerXml);
                                types.Add(ti);
                                type_cache.Add(memberAttr.Substring(2), ti);
                            }
                            else
                            {
                                string name = memberAttr.Substring(2);
                                MemberInfo mi = new MemberInfo(memberAttr.Substring(2), innerXml);
                                string type = extractType(memberAttr);
                                member_cache.Add(name, mi);
                                TypeInfo ti = type_cache[type];
                                ti.Members.Add(mi);
                            }
                        }
                        else if (reader.LocalName == "assembly")
                        {
                            reader.ReadToDescendant("name");
                            assemblyName = reader.ReadElementContentAsString();
                            reader.Read();
                        }
                        break;
                }
            }
            
        }

        private static string extractType(string memberName)
        {
            int sk_ind = memberName.IndexOf("(");
            if (sk_ind != -1)
                memberName = memberName.Substring(0, sk_ind);
            return memberName.Substring(2, memberName.LastIndexOf(".") - 2);
        }

        public static void saveXml()
        {
            XmlTextWriter writer = new XmlTextWriter(xmlFileName, Encoding.UTF8);
            writer.Formatting = Formatting.Indented;
            writer.WriteStartDocument();
            writer.WriteStartElement("doc");
            writer.WriteStartElement("assembly");
            writer.WriteStartElement("name");
            writer.WriteString(assemblyName);
            writer.WriteEndElement();
            writer.WriteEndElement();

            writer.WriteStartElement("members");
            for (int i = 0; i < xmlEntities.Count; i++)
            {
                if (xmlEntities[i].attribute.StartsWith("T:"))
                {
                    if (!type_cache.ContainsKey(xmlEntities[i].attribute.Substring(2)))
                        continue;
                }
                else
                {
                    string type = extractType(xmlEntities[i].attribute);
                    if (!type_cache.ContainsKey(type))
                        continue;
                }
                writer.WriteStartElement("member");
                writer.WriteAttributeString("name", xmlEntities[i].attribute);
                //writer.WriteRaw(xmlEntities[i].innerXml);
                if (xmlEntities[i].attribute.StartsWith("T:"))
                {
                    TypeInfo ti = type_cache[xmlEntities[i].attribute.Substring(2)];
                    writer.WriteRaw(ti.Description);
                    string remarks = ti.Remarks;
                    if (!string.IsNullOrEmpty(remarks))
                        writer.WriteRaw("<remarks>" + remarks + "</remarks>");
                    string sample = ti.SampleCode;

                    if (!string.IsNullOrEmpty(sample))
                        writer.WriteRaw("<example>" + sample + "</example>");
                }
                else
                {
                    //string type = extractType(xmlEntities[i].attribute);
                    MemberInfo mi = member_cache[xmlEntities[i].attribute.Substring(2)];
                    writer.WriteRaw(mi.Description);
                    string remarks = mi.Remarks;
                    if (!string.IsNullOrEmpty(remarks))
                        writer.WriteRaw("<remarks>" + remarks + "</remarks>");
                    string sample = mi.SampleCode;

                    if (!string.IsNullOrEmpty(sample))
                        writer.WriteRaw("<example>" + sample + "</example>");
                }
                writer.WriteEndElement();
            }
            writer.WriteEndElement();
            writer.WriteEndElement();
            writer.WriteEndDocument();
            writer.Close();
        }

        private static string getMemberHref(string name)
        {
            int ind = name.IndexOf('#');
            if (ind != -1)
            {
                name = name.Substring(0, ind-1);
                name += "." + name.Substring(name.LastIndexOf('.') + 1);
            }
            return name.ToLower();
        }

        private static string buildMsdnLink(string name)
        {
            return string.Format("http://msdn.microsoft.com/ru-ru/library/{0}(v=VS.90).aspx#remarksToggle", getMemberHref(name));
        }

        public static void AddMsdnLinks()
        {
            foreach (TypeInfo ti in type_cache.Values)
            {
                if (string.IsNullOrEmpty(ti.Remarks) && !ti.Name.Contains("`"))
                {
                    
                    ti.Remarks = string.Format("См. подробнее в <a href=\"{0}\">MSDN</a>",buildMsdnLink(ti.Name));
                }
            }
            foreach (MemberInfo mi in member_cache.Values)
            {
                if (string.IsNullOrEmpty(mi.Remarks) && !mi.Name.Contains("`"))
                {
                    string name = mi.Name;
                    int ind = mi.Name.IndexOf("(");
                    if (ind != -1)
                        name = name.Substring(0, ind);
                    mi.Remarks = string.Format("См. подробнее в <a href=\"{0}\">MSDN</a>", buildMsdnLink(name));
                }
            }
        }
    }
}
