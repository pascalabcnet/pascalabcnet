﻿using System;
using System.Collections.Generic;

namespace DocCommentEditor
{
    public enum MemberKind
    {
        Field,
        Property,
        Method,
        Event
    }

    public class ObjectInfo
    {
        public string Name;
        public string Description;
        public string Remarks;
        public string SampleCode;

        public ObjectInfo(string Name, string innerXml)
        {
            this.Name = Name;
            int beg_ind = innerXml.IndexOf("<remarks>");
            if (beg_ind != -1)
            {
                int end_ind = innerXml.IndexOf("</remarks>");
                this.Description = innerXml.Substring(0, beg_ind);
                this.Remarks = innerXml.Substring(beg_ind + 9, end_ind - beg_ind - 9);
                beg_ind = innerXml.IndexOf("<example>");
                if (beg_ind != -1)
                {
                    end_ind = innerXml.IndexOf("</example>");
                    this.SampleCode = innerXml.Substring(beg_ind + 9, end_ind - beg_ind - 9);
                }
            }
            else if ((beg_ind = innerXml.IndexOf("<example>")) != -1)
            {
                int end_ind = innerXml.IndexOf("</example>");
                this.Description = innerXml.Substring(0, beg_ind);
                this.SampleCode = innerXml.Substring(beg_ind + 9, end_ind - beg_ind - 9);
            }
            else
                this.Description = innerXml;
        }

    }

    public class TypeInfo : ObjectInfo
    {
       
        public List<MemberInfo> Members = new List<MemberInfo>();

        public TypeInfo(string _Name, string _innerXml): base(_Name,_innerXml)
        {
            
        }
    }

    public class MemberInfo : ObjectInfo
    {
        public MemberKind Kind;
        public List<string> Parameters;

        public MemberInfo(string _Name, string _innerXml): base(_Name, _innerXml)
        {

        }
    }

    public class DocXmlEntity
    {
        public string attribute;
        public string innerXml;

        public DocXmlEntity(string attribute, string innerXml)
        {
            // TODO: Complete member initialization
            this.attribute= attribute;
            this.innerXml = innerXml;
        }
    }
}