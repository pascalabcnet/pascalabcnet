﻿namespace WindowsFormsApplication1
{
    partial class TypeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TypeForm));
            this.tbDescription = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnLoadMsdn = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbParagraph = new System.Windows.Forms.ToolStripButton();
            this.tsbTypeCRef = new System.Windows.Forms.ToolStripButton();
            this.tsbMethodCRef = new System.Windows.Forms.ToolStripButton();
            this.tsbPropertyCRef = new System.Windows.Forms.ToolStripButton();
            this.tsbEventCRef = new System.Windows.Forms.ToolStripButton();
            this.tsbFieldCRef = new System.Windows.Forms.ToolStripButton();
            this.tbRemarks = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tbSample = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dgvMembers = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.tsbCode = new System.Windows.Forms.ToolStripButton();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMembers)).BeginInit();
            this.toolStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbDescription
            // 
            this.tbDescription.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tbDescription.Location = new System.Drawing.Point(12, 25);
            this.tbDescription.Multiline = true;
            this.tbDescription.Name = "tbDescription";
            this.tbDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbDescription.Size = new System.Drawing.Size(608, 68);
            this.tbDescription.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Описание";
            // 
            // btnOK
            // 
            this.btnOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOK.Location = new System.Drawing.Point(461, 397);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 4;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(545, 397);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 5;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnLoadMsdn
            // 
            this.btnLoadMsdn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLoadMsdn.Location = new System.Drawing.Point(507, 99);
            this.btnLoadMsdn.Name = "btnLoadMsdn";
            this.btnLoadMsdn.Size = new System.Drawing.Size(113, 23);
            this.btnLoadMsdn.TabIndex = 6;
            this.btnLoadMsdn.Text = "Загрузить с MSDN";
            this.btnLoadMsdn.UseVisualStyleBackColor = true;
            this.btnLoadMsdn.Visible = false;
            this.btnLoadMsdn.Click += new System.EventHandler(this.btnMsdn_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(12, 128);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(608, 263);
            this.tabControl1.TabIndex = 7;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage1.Controls.Add(this.toolStrip1);
            this.tabPage1.Controls.Add(this.tbRemarks);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(600, 237);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Заметки";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbParagraph,
            this.tsbTypeCRef,
            this.tsbMethodCRef,
            this.tsbPropertyCRef,
            this.tsbEventCRef,
            this.tsbFieldCRef});
            this.toolStrip1.Location = new System.Drawing.Point(3, 3);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(594, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbParagraph
            // 
            this.tsbParagraph.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbParagraph.Image = ((System.Drawing.Image)(resources.GetObject("tsbParagraph.Image")));
            this.tsbParagraph.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbParagraph.Name = "tsbParagraph";
            this.tsbParagraph.Size = new System.Drawing.Size(34, 22);
            this.tsbParagraph.Text = "<p>";
            this.tsbParagraph.Click += new System.EventHandler(this.tsbParagraph_Click);
            // 
            // tsbTypeCRef
            // 
            this.tsbTypeCRef.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbTypeCRef.Image = ((System.Drawing.Image)(resources.GetObject("tsbTypeCRef.Image")));
            this.tsbTypeCRef.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbTypeCRef.Name = "tsbTypeCRef";
            this.tsbTypeCRef.Size = new System.Drawing.Size(70, 22);
            this.tsbTypeCRef.Text = "<cref \"T:\">";
            this.tsbTypeCRef.Click += new System.EventHandler(this.tsbTypeCRef_Click);
            // 
            // tsbMethodCRef
            // 
            this.tsbMethodCRef.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbMethodCRef.Image = ((System.Drawing.Image)(resources.GetObject("tsbMethodCRef.Image")));
            this.tsbMethodCRef.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbMethodCRef.Name = "tsbMethodCRef";
            this.tsbMethodCRef.Size = new System.Drawing.Size(74, 22);
            this.tsbMethodCRef.Text = "<cref \"M:\">";
            this.tsbMethodCRef.Click += new System.EventHandler(this.tsbMethodCRef_Click);
            // 
            // tsbPropertyCRef
            // 
            this.tsbPropertyCRef.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbPropertyCRef.Image = ((System.Drawing.Image)(resources.GetObject("tsbPropertyCRef.Image")));
            this.tsbPropertyCRef.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPropertyCRef.Name = "tsbPropertyCRef";
            this.tsbPropertyCRef.Size = new System.Drawing.Size(70, 22);
            this.tsbPropertyCRef.Text = "<cref \"P:\">";
            this.tsbPropertyCRef.Click += new System.EventHandler(this.tsbPropertyCRef_Click);
            // 
            // tsbEventCRef
            // 
            this.tsbEventCRef.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbEventCRef.Image = ((System.Drawing.Image)(resources.GetObject("tsbEventCRef.Image")));
            this.tsbEventCRef.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbEventCRef.Name = "tsbEventCRef";
            this.tsbEventCRef.Size = new System.Drawing.Size(69, 22);
            this.tsbEventCRef.Text = "<cref \"E:\">";
            this.tsbEventCRef.Click += new System.EventHandler(this.tsbEventCRef_Click);
            // 
            // tsbFieldCRef
            // 
            this.tsbFieldCRef.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbFieldCRef.Image = ((System.Drawing.Image)(resources.GetObject("tsbFieldCRef.Image")));
            this.tsbFieldCRef.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbFieldCRef.Name = "tsbFieldCRef";
            this.tsbFieldCRef.Size = new System.Drawing.Size(69, 22);
            this.tsbFieldCRef.Text = "<cref \"F:\">";
            this.tsbFieldCRef.Click += new System.EventHandler(this.tsbFieldCRef_Click);
            // 
            // tbRemarks
            // 
            this.tbRemarks.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tbRemarks.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbRemarks.Location = new System.Drawing.Point(3, 31);
            this.tbRemarks.Multiline = true;
            this.tbRemarks.Name = "tbRemarks";
            this.tbRemarks.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbRemarks.Size = new System.Drawing.Size(594, 203);
            this.tbRemarks.TabIndex = 0;
            this.tbRemarks.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbRemarks_KeyDown);
            this.tbRemarks.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbRemarks_KeyPress);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.toolStrip2);
            this.tabPage2.Controls.Add(this.tbSample);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(600, 237);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Пример кода";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tbSample
            // 
            this.tbSample.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tbSample.Location = new System.Drawing.Point(3, 31);
            this.tbSample.Multiline = true;
            this.tbSample.Name = "tbSample";
            this.tbSample.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbSample.Size = new System.Drawing.Size(594, 203);
            this.tbSample.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dgvMembers);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(600, 237);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Члены";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dgvMembers
            // 
            this.dgvMembers.AllowUserToAddRows = false;
            this.dgvMembers.AllowUserToDeleteRows = false;
            this.dgvMembers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMembers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2});
            this.dgvMembers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvMembers.Location = new System.Drawing.Point(3, 3);
            this.dgvMembers.Name = "dgvMembers";
            this.dgvMembers.Size = new System.Drawing.Size(594, 231);
            this.dgvMembers.TabIndex = 0;
            this.dgvMembers.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvMembers_CellDoubleClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Имя";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 200;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Описание";
            this.Column2.Name = "Column2";
            this.Column2.Width = 400;
            // 
            // toolStrip2
            // 
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbCode});
            this.toolStrip2.Location = new System.Drawing.Point(3, 3);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(594, 25);
            this.toolStrip2.TabIndex = 1;
            this.toolStrip2.Text = "toolStrip2";
            // 
            // tsbCode
            // 
            this.tsbCode.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbCode.Image = ((System.Drawing.Image)(resources.GetObject("tsbCode.Image")));
            this.tsbCode.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbCode.Name = "tsbCode";
            this.tsbCode.Size = new System.Drawing.Size(33, 22);
            this.tsbCode.Text = "<c>";
            this.tsbCode.Click += new System.EventHandler(this.tsbCode_Click);
            // 
            // TypeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 432);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btnLoadMsdn);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbDescription);
            this.MaximizeBox = false;
            this.Name = "TypeForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TypeForm";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMembers)).EndInit();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbDescription;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnLoadMsdn;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox tbRemarks;
        private System.Windows.Forms.TextBox tbSample;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dgvMembers;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbParagraph;
        private System.Windows.Forms.ToolStripButton tsbTypeCRef;
        private System.Windows.Forms.ToolStripButton tsbMethodCRef;
        private System.Windows.Forms.ToolStripButton tsbPropertyCRef;
        private System.Windows.Forms.ToolStripButton tsbEventCRef;
        private System.Windows.Forms.ToolStripButton tsbFieldCRef;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripButton tsbCode;
    }
}