﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Xml;
using System.Windows.Forms;
using DocCommentEditor;

namespace WindowsFormsApplication1
{
    public partial class TypesForm : Form
    {
        public TypesForm()
        {
            InitializeComponent();
        }

        private void Clear()
        {
            XmlCommentManager.Clear();
            dgvTypes.Rows.Clear();
        }

        private void btnLoadXml_Click(object sender, EventArgs e)
        {
            DialogResult dr = openXmlFileDialog.ShowDialog();
            if (dr == DialogResult.OK)
            {
                Clear();
                XmlCommentManager.loadXml(openXmlFileDialog.FileName);
                XmlCommentManager.XmlFileName = openXmlFileDialog.FileName;
                for (int i = 0; i < XmlCommentManager.Types.Count; i++)
                {
                    dgvTypes.Rows.Add(XmlCommentManager.Types[i].Name, XmlCommentManager.Types[i].Description);
                    Utils.highlightRow(XmlCommentManager.Types[i], dgvTypes.Rows[i]);
                }
            }
        }

        private void btnSaveXml_Click(object sender, EventArgs e)
        {
            XmlCommentManager.saveXml();
            MessageBox.Show("Файл успешно сохранен");
        }

        private void dgvTypes_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            TypeForm tf = new TypeForm();
            tf.EditedType = XmlCommentManager.Types[e.RowIndex];
            if (tf.ShowDialog() == DialogResult.OK)
            {
                tf.EditedType.Remarks = tf.Remarks;
                tf.EditedType.SampleCode = tf.SampleCode;
                Utils.highlightRow(tf.EditedType, dgvTypes.Rows[e.RowIndex]);
            }
        }

        private void dgvTypes_UserDeletedRow(object sender, DataGridViewRowEventArgs e)
        {
            
        }

        private void dgvTypes_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            TypeInfo ti = XmlCommentManager.Types[e.Row.Index];
            XmlCommentManager.TypeCache.Remove(ti.Name);
            XmlCommentManager.Types.RemoveAt(e.Row.Index);
        }

        private void btnAddMSDNLinks_Click(object sender, EventArgs e)
        {
            XmlCommentManager.AddMsdnLinks();
            MessageBox.Show("Ссылки на заметки успешно добавлены");
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.dgvTypes.Rows.Clear();
            XmlCommentManager.Clear();
        }

    }
}
